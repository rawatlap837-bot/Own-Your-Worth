import { CalendarDays, Clock3, Radio } from 'lucide-react'
import { event, ctaLabel } from '../data/content'

const headline = [
  'Feel Visible.',
  'Feel Valued.',
  'Rebuild Your Confidence.',
  'Reclaim Your Purpose.',
  'Create Your Financial Independence.',
]

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-ink pt-32 pb-24 md:pt-40 md:pb-32">
      {/* signature moment: two soft drifting fields of colour behind the type */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 -left-24 h-[30rem] w-[30rem] rounded-full bg-amethyst/40 blur-[110px] animate-drift"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-40 -right-16 h-[26rem] w-[26rem] rounded-full bg-gold/25 blur-[120px] animate-drift"
        style={{ animationDelay: '3s' }}
      />

      <div className="relative mx-auto max-w-4xl px-6 md:px-10">
        <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-sm text-amethyst-pale">
          <span className="h-1.5 w-1.5 rounded-full bg-gold" />
          Masterclass for Mothers
        </div>

        <h1 className="mt-8 font-display text-cream">
          {headline.map((line, i) => (
            <span
              key={line}
              className="animate-rise block leading-[1.08] balance"
              style={{
                animationDelay: `${0.12 * (i + 1)}s`,
                fontSize: `clamp(${1.9 + i * 0.12}rem, ${4.4 - i * 0.28}vw, ${2.6 + i * 0.16}rem)`,
                marginLeft: `${i * 0.6}rem`,
                fontWeight: i === headline.length - 1 ? 600 : 500,
              }}
            >
              {line}
            </span>
          ))}
        </h1>

        <p
          className="animate-rise mt-8 max-w-lg text-amethyst-pale/90 font-body"
          style={{ animationDelay: '0.8s' }}
        >
          {event.seatsNote}
        </p>

        <div
          className="animate-rise mt-10 flex flex-col gap-5 sm:flex-row sm:items-center"
          style={{ animationDelay: '0.95s' }}
        >
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 rounded-2xl border border-dashed border-white/20 px-5 py-4 text-sm text-cream/90">
            <span className="flex items-center gap-2">
              <CalendarDays className="h-4 w-4 text-gold" strokeWidth={1.75} />
              {event.day}, {event.date}
            </span>
            <span className="flex items-center gap-2">
              <Clock3 className="h-4 w-4 text-gold" strokeWidth={1.75} />
              {event.time}
            </span>
            <span className="flex items-center gap-2">
              <Radio className="h-4 w-4 text-gold" strokeWidth={1.75} />
              {event.format}
            </span>
          </div>
        </div>

        <a
          id="reserve"
          href="#reserve-form"
          className="animate-rise mt-10 inline-flex items-center justify-center rounded-full bg-gold px-8 py-4 font-body text-base font-semibold text-ink shadow-[0_10px_30px_-8px_rgba(217,164,65,0.5)] transition-transform hover:scale-[1.02] hover:bg-gold-soft"
          style={{ animationDelay: '1.1s' }}
        >
          {ctaLabel}
        </a>
      </div>
    </section>
  )
}
