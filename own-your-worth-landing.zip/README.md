# Own Your Worth — Masterclass Landing Page

A React + Tailwind landing page built from the "Own Your Worth" masterclass
content, in a plum / amethyst / gold palette.

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL it prints (usually http://localhost:5173).

## Build for deployment

```bash
npm run build
```

This outputs a static site to `dist/` — upload that folder to Netlify,
Vercel, GitHub Pages, or any static host.

## Before you launch — things to edit

Everything editable lives in **`src/data/content.js`**:

1. **Event details** — replace `[DAY]`, `[DATE]`, `[TIME]` with the real
   date and time of the masterclass.
2. **Testimonials** — the three testimonials are placeholders (marked
   `[Client name]`). Swap in real quotes and names before launch.
3. **Coach photo** — drop a real photo at `public/coach.jpg` (any image,
   ideally square) and it will automatically replace the monogram
   placeholder. No code changes needed.
4. **Registration form** — the final CTA includes a working name/email
   form. Right now it only shows a local "you're on the list" confirmation.
   To connect it to a real signup flow (Zoom registration, Mailchimp,
   a Zapier webhook, etc.), set `registrationEndpoint` in
   `src/data/content.js` to that URL — the form will POST to it.

## Project structure

```
src/
  data/content.js       ← all copy and editable content
  components/           ← one file per landing page section
  App.jsx                ← assembles the sections in order
  index.css              ← Tailwind + base styles
tailwind.config.js        ← color palette and type scale (design tokens)
```

## Design notes

- Colors: deep plum/ink backgrounds bookend the page (hero + final CTA),
  with cream and soft lilac sections in between; gold is reserved for
  calls to action so it stays meaningful.
- Type: Fraunces (serif, display) paired with Work Sans (body).
- The hero headline cascades line by line to build toward the boldest
  promise ("financial independence") rather than using a single flat
  headline.
- Motion is a single orchestrated entrance on the hero plus two slow
  drifting color fields — not per-card hover animations — and respects
  `prefers-reduced-motion`.
